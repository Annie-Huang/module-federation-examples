import './App.css';
declare const App: (info?: {
    abc?: string;
}) => import("react/jsx-runtime").JSX.Element;
export default App;
